// Non copyable type

struct FileHandle: ~Copyable {
    var descriptor: Int

    deinit {
        print("Closing file descriptor \(descriptor) \n")
    }

    consuming func close() {
        print("Closing handle \(descriptor)")
    }
}

        // Methods 

func useHandle(_ handle: borrowing FileHandle) {
    print("Using handle \(handle.descriptor)")
}

func takeHandle(_ handle: consuming FileHandle) -> FileHandle {
    print("Taking ownership of \(handle.descriptor)")
    return handle
}

        // Calling functions with borrowing property.

func borrowing() {
    var fileHandle = FileHandle(descriptor: 10)
    useHandle(fileHandle) // ✅ OK, fileHandle stay valid
    useHandle(fileHandle) // ✅ OK, can be used again
}

borrowing()

        // Calling functions with consumed property.

func consuming() {
    var fileHandle = FileHandle(descriptor: 20)
    var newFileHandle = takeHandle(fileHandle) // ownership consumed, fileHandle unavailable ❌
    print("Func that consumed fileHandle returns old value as a brand new \(newFileHandle.descriptor)")
//    useHandle(fileHandle)  // ❌ compilation error: fileHandle consumed already. Uncomment ⌘ + .
    useHandle(newFileHandle)  // ✅ OK, can be used again
}

consuming()

        // Calling consuming method

func consumingMethod() {
    var fileHandle = FileHandle(descriptor: 30)
    useHandle(fileHandle) // ✅ OK, fileHandle stay valid
    fileHandle.close()
//    useHandle(fileHandle) // ❌ Consumed. Can't used. Compilation error. Uncomment ⌘ + .
}

consumingMethod()
